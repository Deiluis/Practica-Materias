#include "lista.h"

void crearLista(tLista* lista) {
    *lista = NULL;
}

int enlistarAlFinal(tLista* lista, const void* elem, unsigned len) {
    tNodo* newNode = malloc(sizeof(tNodo));
    if (!newNode)
        return ERR_MEM;
    newNode->info = malloc(len);
    if (!newNode->info) {
        free(newNode);
        return ERR_MEM;
    }

    newNode->len = len;
    newNode->next = NULL;
    memcpy(newNode->info, elem, len);

    while (*lista)
        lista = &((*lista)->next);

    *lista = newNode;

    return OK;
}

int enlistarOrdConDupl(tLista* lista, const void* elem, unsigned len, Cmp cmp) {
    tNodo* newNode = malloc(sizeof(tNodo));
    if (!newNode)
        return ERR_MEM;
    newNode->info = malloc(len);
    if (!newNode->info) {
        free(newNode);
        return ERR_MEM;
    }

    newNode->len = len;
    memcpy(newNode->info, elem, len);

    while (*lista && cmp((*lista)->info, elem) < 0)
        lista = &((*lista)->next);

    newNode->next = *lista;
    *lista = newNode;

    return OK;
}

int enlistarOrdSinDupl(tLista* lista, const void* elem, unsigned len, Cmp cmp) {
    tNodo* newNode = malloc(sizeof(tNodo));
    if (!newNode)
        return ERR_MEM;
    newNode->info = malloc(len);
    if (!newNode->info) {
        free(newNode);
        return ERR_MEM;
    }

    newNode->len = len;
    memcpy(newNode->info, elem, len);

    while (*lista && cmp((*lista)->info, elem) < 0)
        lista = &((*lista)->next);

    if (!*lista || cmp((*lista)->info, elem) != 0) {
        newNode->next = *lista;
        *lista = newNode;
    }

    return OK;
}

int enlistarOrd(tLista* lista, const void* elem, unsigned len, Cmp cmp, bool dupl) {
    return dupl ? enlistarOrdConDupl(lista,elem,len,cmp) : enlistarOrdSinDupl(lista,elem,len,cmp);
}

int enlistarSinDuplAct(tLista* lista, const void* elem, unsigned len, Cmp cmp, void update(void* orig, const void* toUpd)) {
    tNodo* newNode = malloc(sizeof(tNodo));
    if (!newNode)
        return ERR_MEM;
    newNode->info = malloc(len);
    if (!newNode->info) {
        free(newNode);
        return ERR_MEM;
    }

    newNode->len = len;
    memcpy(newNode->info, elem, len);

    while (*lista && cmp((*lista)->info, elem) < 0)
        lista = &((*lista)->next);

    if (!*lista) {
        newNode->next = NULL;
        *lista = newNode;
    }
    else if ( cmp((*lista)->info, elem) == 0)
        update((*lista)->info, elem);
    else {
        newNode->next = *lista;
        (*lista) = newNode;
    }

    return OK;
}

void ordenar(tLista* lista, Cmp cmp) {
    tLista* first = lista;

    if (*lista == NULL)
        return;

    while ((*lista)->next) {
        if (cmp((*lista)->info, (*lista)->next->info) > 0) { // means the next one it's not in order
            tLista* auxLista = first;
            tNodo* auxNodo = (*lista)->next;

            (*lista)->next = auxNodo->next;

            while (cmp((*auxLista)->info, auxNodo->info) < 0)
                auxLista = &(*auxLista)->next;

            auxNodo->next = *auxLista;
            *auxLista = auxNodo;
        }
        else
            lista = &(*lista)->next;

    }

}

void mostrarLista(const tLista* lista, void repr(const void* elem)) {
    while (*lista) {
        repr((*lista)->info);
        lista = &((*lista)->next);
    }
}

void vaciarLista(tLista* lista) {
    tNodo* auxElim;
    while (*lista) {
        auxElim = *lista;
        *lista = auxElim->next;
        free(auxElim->info);
        free(auxElim);
    }
}

int listaVacia(tLista* lista) {
    return *lista ? LISTA_NO_VACIA : LISTA_VACIA;
}


