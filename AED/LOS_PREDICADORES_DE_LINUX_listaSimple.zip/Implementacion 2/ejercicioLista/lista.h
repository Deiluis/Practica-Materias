#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define true 1
#define false 0

#define OK 0
#define ERR_MEM 1
#define ERR_FILE 2
#define LISTA_VACIA 3
#define LISTA_NO_VACIA 4

typedef int bool;

typedef struct sNodo {
    unsigned len;
    void* info;
    struct sNodo* next;
} tNodo;

typedef tNodo* tLista;

typedef int (*Cmp)(const void*, const void*);

void crearLista(tLista* lista);
int enlistarAlFinal(tLista* lista, const void* elem, unsigned len);
int enlistarOrdConDupl(tLista* lista, const void* elem, unsigned len, Cmp cmp);
int enlistarOrdSinDupl(tLista* lista, const void* elem, unsigned len, Cmp cmp);
int enlistarOrd(tLista* lista, const void* elem, unsigned len, Cmp cmp, bool dupl);
int enlistarSinDuplAct(tLista* lista, const void* elem, unsigned len, Cmp cmp, void update(void* orig, const void* toUpd));

void ordenar(tLista* lista, Cmp cmp);


void mostrarLista(const tLista* lista, void repr(const void* elem));
void vaciarLista(tLista* lista);
int listaVacia(tLista* lista);



#endif // LISTA_H_INCLUDED
