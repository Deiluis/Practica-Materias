#include <stdio.h>
#include <stdlib.h>

#include "lista.h"

#define TAM_BUF_LINE 50

#define true 1
#define false 0
typedef int bool;

typedef struct {
    int dni;
    char nya[20];
    float nota;
} tAlumno;

int cargarListaSimple(tLista* listaSimple, char* pathFile);
int cargarListaCompleja(tLista* listaCompleja, char* pathFile);

int menu(tLista* lista, void newElem(tLista* lista, Cmp compare), void repr(const void* elem), Cmp cmp, void order(tLista* lista), void save(tLista* lista, char* pathFile), char* pathSave);


void showAlumno(const void* elem);
void fillListValues(tLista* lista, void* vecInfo, unsigned lenVec, unsigned sizeElem);
int cmpAlumnoNombre(const void* a, const void* b);
int cmpAlumnoDni(const void* a, const void* b);
int cmpAlumnoGral(const void* a, const void* b);
int cmpAlumnoNota(const void* a, const void* b);
void updAlumno(void* orig, const void* toUpd);

void newElemListaCompleja(tLista* lista, Cmp cmp);
void newElemListaSimple(tLista* lista, Cmp cmp);
void orderListaSimple(tLista* lista);
void orderListaCompleja(tLista* lista);
void saveListaSimple(tLista* lista, char* pathFile);
void saveListaCompleja(tLista* lista, char* pathFile);


void showFloat(const void* elem);
int cmpFloat (const void* a, const void* b);

int main()
{
    tAlumno alumnsArray[] = {
        {101, "Ana", 8.5},
        {102, "Carlos", 7.2},
        {103, "Beatriz", 9.1},
        {104, "David", 6.8},
        {105, "Elena", 8.9},
        {106, "Fernando", 7.5},
        {107, "Gabriela", 6.2},
        {108, "Hector", 8.7},
        {109, "Isabel", 9.3},
        {110, "Javier", 7.8},
        {101, "Ana Maria", 8.0},
        {102, "Carlos Alberto", 7.4},
        {103, "Beatriz Elena", 8.6},
        {201, "Ana", 6.9},
        {202, "Carlos", 8.2},
        {203, "Beatriz", 7.7},
        {301, "maria", 5.5},
        {302, "Maria", 8.8},
        {303, "MARIA", 7.1},
        {304, "jose", 6.5},
        {305, "Jose", 8.4},
        {306, "JOSE", 7.9},
        {401, "Maria del Carmen", 9.0},
        {402, "Juan Carlos", 7.3},
        {403, "Ana Sofia", 8.1},
        {404, "Luis Miguel", 6.7},
        {405, "Jos� Mar�a", 8.3},
        {406, "Mar�a Jos�", 7.6},
        {501, "Pedro", 9.2},
        {502, "Laura", 6.4},
        {503, "Miguel", 8.0},
        {504, "Sofia", 7.8},
        {505, "Andres", 6.9},
        {506, "Carmen", 8.5},
        {507, "Ricardo", 7.2},
        {508, "Patricia", 8.7},
        {509, "Oscar", 6.8},
        {510, "Rosa", 9.1},
        {1001, "Teresa", 7.4},
        {1005, "Roberto", 8.2},
        {1010, "Monica", 6.6},
        {1020, "Francisco", 8.9},
        {1030, "Alejandra", 7.5},
        {1040, "Eduardo", 9.3},
        {1050, "Silvia", 7.0},
        {1060, "Ramon", 8.1}
    };

    //float floatArray[] = {1.2, 2.4, 6.82, 75.02, 200, 1020.8, 9.99, 53.4};
    float floatArray[] = {1,2,3,4,5};

    tLista miListaSimple, miListaCompleja;
    crearLista(&miListaSimple);
    crearLista(&miListaCompleja);

    if (cargarListaSimple(&miListaSimple, "listaSimple.txt") != OK) {
        fillListValues(&miListaSimple, floatArray, sizeof(floatArray)/sizeof(float), sizeof(float));
        printf("listaSimple default\n");
    }
    if (cargarListaCompleja(&miListaCompleja, "listaCompleja.dat") != OK) {
        fillListValues(&miListaCompleja, alumnsArray, sizeof(alumnsArray)/sizeof(tAlumno), sizeof(tAlumno));
        printf("listaCompleja default\n");
    }

    printf("Info inicial:\n\nlistaSimple:\n");
    mostrarLista(&miListaSimple, showFloat);
    printf("\nlistaCompleja:\n");
    mostrarLista(&miListaCompleja, showAlumno);
    printf("\n\n\n");

    bool exit = false;
    char bufferLine[20];
    while (!exit) {
        printf("Op (exit/simple/compleja): ");
        scanf("%s", bufferLine);
        if (strcmp(bufferLine, "exit") == 0)
            exit = true;
        if (strcmp(bufferLine, "simple") == 0)
            menu(&miListaSimple, newElemListaSimple, showFloat, cmpFloat, orderListaSimple, saveListaSimple, "listaSimple.txt");
        if (strcmp(bufferLine, "compleja") == 0)
            menu (&miListaCompleja, newElemListaCompleja, showAlumno, cmpAlumnoGral, orderListaCompleja, saveListaCompleja, "listaCompleja.dat");
    }

    return OK;
}

void showAlumno(const void* elem) {
    tAlumno* alumno = (tAlumno*)elem;
    printf("<Alumno %d %s %5.2f>\n", alumno->dni, alumno->nya, alumno->nota);
}
int cmpAlumnoNombre(const void* a, const void* b) {
    tAlumno* a2 = (tAlumno*)a;
    tAlumno* b2 = (tAlumno*)b;
    return strcmpi(a2->nya, b2->nya);
}
int cmpAlumnoDni(const void* a, const void* b) {
    tAlumno* a2 = (tAlumno*)a;
    tAlumno* b2 = (tAlumno*)b;
    return a2->dni - b2->dni;
}
int cmpAlumnoGral(const void* a, const void* b) {
    return cmpAlumnoDni(a,b) != 0 ? cmpAlumnoDni(a,b) : cmpAlumnoNombre(a,b);
}
int cmpAlumnoNota(const void* a, const void* b) {
    tAlumno* a2 = (tAlumno*)a;
    tAlumno* b2 = (tAlumno*)b;
    return (a2->nota - b2->nota) > 0 ? -1 : (a2->nota - b2->nota) == 0 ? 0 : 1;
}
void updAlumno(void* orig, const void* toUpd) {
    tAlumno* original = orig;
    const tAlumno* toUpdate = toUpd;
    original->dni = toUpdate->dni;
    original->nota = toUpdate->nota;
}

void showFloat(const void* elem) {
    float* f = (float*)elem;
    printf("%f\n", *f);
}
int cmpFloat (const void* a, const void* b) {
    float* a2 = (float*)a;
    float* b2 = (float*)b;
    return *a2-*b2 < 0 ? -1 : *a2-*b2 == 0 ? 0 : 1;
}


int menu(tLista* lista, void newElem(tLista* lista, Cmp compare), void repr(const void* elem), Cmp cmp, void order(tLista* lista), void save(tLista* lista, char* pathFile), char* pathSave) {
    int exit = 0;
    char bufferOp[5];

    while (!exit) {
        printf("\nOp (exit, more, ask, order, save): ");
        scanf("%s", bufferOp);

        if (!strcmp(bufferOp, "exit")) {exit = 1;}
        if (!strcmp(bufferOp, "more")) {
            newElem(lista, cmp);
        }
        if (!strcmp(bufferOp, "ask")) {
            printf("\n");
            mostrarLista(lista, repr);
        }
        if (!strcmp(bufferOp, "order")) {
            order(lista);
        }
        if (!strcmp(bufferOp, "save")) {
            save(lista, pathSave);
        }
    }

    return OK;
}



void fillListValues(tLista* lista, void* vecInfo, unsigned lenVec, unsigned sizeElem) {
    for (char* i= (char*)vecInfo; i < (char*)vecInfo + lenVec * sizeElem; i+=sizeElem)
        enlistarAlFinal(lista, i, sizeElem);
}

int cargarListaSimple(tLista* listaSimple, char* pathFile) {
    FILE* file = fopen(pathFile, "rt");
    if (!file)
        return ERR_FILE;

    char bufferLine[TAM_BUF_LINE];
    float bufferItem;

    while (fgets(bufferLine, TAM_BUF_LINE, file)) {
        sscanf(bufferLine, "%f", &bufferItem);
        enlistarAlFinal(listaSimple, &bufferItem, sizeof(float));
    }

    fclose(file);
    return OK;
}

int cargarListaCompleja(tLista* listaCompleja, char* pathFile) {
    FILE* file = fopen(pathFile, "rb");
    if (!file)
        return ERR_FILE;

    tAlumno bufferAlu;
    while (fread(&bufferAlu, sizeof(tAlumno), 1, file))
        enlistarAlFinal(listaCompleja, &bufferAlu, sizeof(tAlumno));

    fclose(file);
    return OK;
}

void newElemListaCompleja(tLista* lista, Cmp cmp) {
    tAlumno buffer;
    char bufferResp[20];
    bool dupl;
    printf("\nNuevo alumno (nombre dni nota): ");
    scanf("%s %d %f", buffer.nya, &buffer.dni, &buffer.nota);
    printf("\nAcepta duplicados (si/no): ");
    scanf("%s", bufferResp);
    dupl = strcmp(bufferResp, "si") ? true : false;

    if (dupl) {
        if (enlistarSinDuplAct(lista, &buffer, sizeof(tAlumno), cmp, updAlumno) == OK) {
            printf("\nInfo agregada: ");
            showAlumno(&buffer);
        }
    } else {
        if (enlistarOrdSinDupl(lista, &buffer, sizeof(tAlumno), cmp) == OK) {
            printf("\nInfo agregada: ");
            showAlumno(&buffer);
        }
    }
}

void newElemListaSimple(tLista* lista, Cmp cmp) {
    float buffer;
    char bufferResp[20];
    bool dupl;
    printf("\nNuevo numero: ");
    scanf("%f", &buffer);
    printf("\nAcepta duplicados (si/no): ");
    scanf("%s", bufferResp);
    dupl = strcmp(bufferResp, "si")==0 ? true : false;

    if (dupl) {
        if (enlistarOrdConDupl(lista, &buffer, sizeof(float), cmp) == OK) {
            printf("\nInfo agregada: ");
            showFloat(&buffer);
        }
    } else {
        if (enlistarOrdSinDupl(lista, &buffer, sizeof(float), cmp) == OK) {
            printf("\nInfo agregada: ");
            showFloat(&buffer);
        }
    }
}

void orderListaSimple(tLista* lista) {
    ordenar(lista, cmpFloat);
}

void orderListaCompleja(tLista* lista) {
    char buf[20];
    printf("\nCriterio de ordenamiento (dni/nombre/gral/nota): ");
    scanf("%s", buf);
    if (!strcmp(buf, "dni"))
        ordenar(lista, cmpAlumnoDni);
    if (!strcmp(buf, "nombre"))
        ordenar(lista, cmpAlumnoNombre);
    if (!strcmp(buf, "gral"))
        ordenar(lista, cmpAlumnoGral);
    if (!strcmp(buf, "nota"))
        ordenar(lista, cmpAlumnoNota);
}

void saveListaSimple(tLista* lista, char* pathFile) {
    FILE* file = fopen(pathFile, "wt");
    while (*lista) {
        fprintf(file, "%f\n", *(float*)(*lista)->info);
        lista = &(*lista)->next;
    }
    fclose(file);
}

void saveListaCompleja(tLista* lista, char* pathFile) {
    FILE* file = fopen(pathFile, "wt");
    if (!file)
        return;
    while (*lista) {
        fwrite((*lista)->info, sizeof(tAlumno), 1, file);
        lista = &(*lista)->next;
    }
    fclose(file);
}


