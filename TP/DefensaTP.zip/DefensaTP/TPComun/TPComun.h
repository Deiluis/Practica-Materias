#ifndef TPCOMUN_H_INCLUDED
#define TPCOMUN_H_INCLUDED

#define bool int
#define true 1
#define false 0

#define TODO_OK 0
#define ERR_ARCHIVO 1
#define SIN_MEM 2
#define ERR_BUFFER_CORTO 3
#define TAMANOS_INCOMPATIBLES 4
#define NO_ELEGIDO 5
#define DUPLICADO 6
#define FUERA_RANGO 7

#endif
