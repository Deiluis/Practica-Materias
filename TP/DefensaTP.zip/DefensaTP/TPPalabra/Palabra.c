#include "Palabra.h"

void palabraModificar (Palabra* pal, Modif modif) {
    modif(pal -> vPal);
}
